# 可直接执行的 Commands 范例

每个代码块都是完整事务，均从本 ZIP 初始 sceneRevision 出发；任选其一，复制到 work/commands.json 后运行 apply、preview。它们是替代方案，不要连续执行。实际作品请根据素材与意图修改坐标和文字。若要在本次 apply 后继续修改，先用 info 获取新 baseSceneRevision 并更换 transactionId。

## 完整素材、可编辑文字、圆形和荧光笔

```json

{
  "protocolVersion": 1,
  "transactionId": "recipe-simple-d09f7586",
  "baseSceneRevision": "sha256:d9f716d11b572965a62e5dde649dfdfcb0d7a1dafb77c9abff2eed02c1827007",
  "operations": [
    {
      "op": "material.add",
      "id": "hero",
      "asset": "m1",
      "placement": {
        "xMm": 148,
        "yMm": 105
      }
    },
    {
      "op": "text.add",
      "id": "heading",
      "content": "这一页，从眼前的素材开始。",
      "xMm": 74,
      "yMm": 16,
      "widthMm": 148,
      "fontSizePt": 20
    },
    {
      "op": "shape.add",
      "id": "dot",
      "kind": "ellipse",
      "xMm": 213,
      "yMm": 28,
      "widthMm": 8,
      "heightMm": 8,
      "fill": "#d5e2d6"
    },
    {
      "op": "ink.add",
      "id": "highlight",
      "points": [
        {
          "xMm": 74,
          "yMm": 42
        },
        {
          "xMm": 163,
          "yMm": 42
        }
      ],
      "widthMm": 3,
      "color": "#e8d66b",
      "penStyle": "marker"
    },
    {
      "op": "material.decision",
      "asset": "m1",
      "choice": "intact",
      "reason": "保留原件作为本页视觉主体"
    },
    {
      "op": "material.decision",
      "asset": "m2",
      "choice": "omitted",
      "reason": "本页暂不使用这一件候选素材"
    },
    {
      "op": "material.decision",
      "asset": "m3",
      "choice": "omitted",
      "reason": "本页暂不使用这一件候选素材"
    }
  ]
}

```

## 本任务来源版本的工艺事务

```json

{
  "protocolVersion": 1,
  "transactionId": "recipe-d09f7586",
  "baseSceneRevision": "sha256:d9f716d11b572965a62e5dde649dfdfcb0d7a1dafb77c9abff2eed02c1827007",
  "operations": [
    {
      "op": "material.craft",
      "plan": {
        "format": "shiye-craft-plan",
        "version": 2,
        "commandId": "recipe-craft-d09f7586",
        "baseSceneHash": "sha256:28aaf27303d01d04e66617f6522b1493d91215bf3ab8582b8ca7fa1d3fe002ef",
        "pieces": [
          {
            "id": "recipe-piece",
            "asset": "m1",
            "sourceRevision": "sha256:ccb0846274bf4b9ad0a8d034fa6e83088fc506e9bf9f6bd3b475b75651ba2d59",
            "unit": 0,
            "extraction": {
              "type": "whole"
            },
            "centerMM": [
              148,
              105
            ],
            "treatments": [
              {
                "op": "window",
                "shape": "ellipse",
                "box": [
                  0.35,
                  0.35,
                  0.2,
                  0.2
                ]
              }
            ]
          }
        ]
      }
    },
    {
      "op": "material.decision",
      "asset": "m1",
      "choice": "crafted",
      "reason": "依据素材轮廓创建当前可见裁片"
    },
    {
      "op": "material.decision",
      "asset": "m2",
      "choice": "omitted",
      "reason": "本页暂不使用这一件候选素材"
    },
    {
      "op": "material.decision",
      "asset": "m3",
      "choice": "omitted",
      "reason": "本页暂不使用这一件候选素材"
    }
  ]
}

```

复杂裁切、边缘、余料、窗芯、穿插可在 material.craft.plan 的 pieces/sourcePartitions/consume/weaves 内组合；按需查看 api/commands.schema.json 中对应 op。局部修改统一用下一批 operations，layer.update 只能修改白名单里的 Scene 字段。所有带 Mm/Deg/Pt 后缀的值使用相应单位；Craft Plan 的 boxMM 是源材料毫米，比例 box 值在 0 到 1 之间。
