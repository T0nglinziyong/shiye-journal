# Commands 范例

两个范例都从初始 Scene 开始，任选一个，复制到 work/commands.json 执行。请根据本次素材和文字重新构思；示例只是语法，不是完整作品。每次 apply 后用 info 获取新 revision，并换用新 transactionId。

## 素材、文字、圆形与荧光笔

```json

{
  "protocolVersion": 2,
  "transactionId": "recipe-simple-f731122e",
  "baseSceneRevision": "sha256:0e83a3ab40291cd4eb1021fae3419adf364a822005fd936b867f7eb7aa69736d",
  "operations": [
    {
      "op": "material.add",
      "id": "hero",
      "asset": "m1",
      "place": {
        "reference": "page",
        "at": [
          0.5,
          0.5
        ],
        "unit": "ratio"
      }
    },
    {
      "op": "text.add",
      "id": "heading",
      "content": "这一页，从眼前的素材开始。",
      "place": {
        "reference": "page",
        "at": [
          0.25,
          0.08
        ],
        "unit": "ratio"
      },
      "size": {
        "width": 0.5,
        "unit": "ratio",
        "reference": "page"
      },
      "style": {
        "fontSizePt": 20
      }
    },
    {
      "op": "shape.add",
      "id": "dot",
      "kind": "ellipse",
      "place": {
        "reference": "page",
        "at": [
          0.72,
          0.2
        ],
        "unit": "ratio"
      },
      "size": {
        "width": 8,
        "height": 8,
        "unit": "mm"
      },
      "style": {
        "fill": "#d5e2d6"
      }
    },
    {
      "op": "ink.add",
      "id": "highlight",
      "points": [
        {
          "x": 0,
          "y": 0
        },
        {
          "x": 30,
          "y": 0
        }
      ],
      "unit": "mm",
      "place": {
        "reference": "page",
        "at": [
          0.42,
          0.3
        ],
        "unit": "ratio"
      },
      "style": {
        "strokeWidthMm": 3,
        "color": "#e8d66b",
        "penStyle": "marker"
      }
    }
  ]
}

```

## 实体开窗

```json

{
  "protocolVersion": 2,
  "transactionId": "recipe-craft-f731122e",
  "baseSceneRevision": "sha256:0e83a3ab40291cd4eb1021fae3419adf364a822005fd936b867f7eb7aa69736d",
  "operations": [
    {
      "op": "material.add",
      "id": "source",
      "asset": "m1",
      "place": {
        "reference": "page",
        "at": [
          0.5,
          0.5
        ],
        "unit": "ratio"
      }
    },
    {
      "op": "material.window",
      "target": "source",
      "windowId": "window-1",
      "region": {
        "shape": "ellipse",
        "space": "local",
        "unit": "ratio",
        "box": [
          0.35,
          0.35,
          0.2,
          0.2
        ]
      }
    }
  ]
}

```

默认只读 api/commands.schema.json 中的简洁操作。复杂来源分片、余料、窗芯、穿插和局部组都在同一份 commands.json 中；原有 39 项能力可用 advanced.v1.* 调用。纸张模式和尺寸由任务固定。layout.arrange 与 visible 锚点暂不提供。
