# 拾页 GPT 创作包 v3
读 TASK.json 与 design/GUIDE.md，看 assets/overview.jpg 和必要原图。scene.json 是唯一作品。
1. 运行 node runtime/shiye.cjs self-test 和 info，复制 sceneRevision。
2. 在 work/commands.json 中写一个事务，operations 可混合素材、文字、图形和工艺。
3. 运行 node runtime/shiye.cjs apply work/commands.json，再运行 preview。
4. 打开 output/preview.png 看整页和局部；下一批用新 transactionId 和 info 的新 revision 只修改问题图层。
5. 补齐逐件 material.decision，再运行 preview 和 pack。交付 output/project.shiyeproject.json 与 output/preview.png。
复杂工艺按需查 design/RECIPES.md，字段不清时查 api/commands.schema.json。不要先读完整 Schema，也不要写辅助 Python/JS 修改 Scene。
预览失败时运行 self-test 并检查 Node Canvas 依赖；失败前不能交付 PNG。pack 不会替你伪造视觉验收。
