# 协议 2 创作包实验示例

本包是同一 Scene/Canvas 链路的可运行实验包，尚不是正式默认发行版。先运行 `node runtime/shiye.cjs self-test` 和 `node runtime/shiye.cjs info`。

`work/commands.json` 已包含一份协议 2 示例，可依次运行 `check work/commands.json`、`apply work/commands.json`、`preview`、`pack`。交付文件位于 `output/`。后续事务可运行 `begin work/next.json --protocol=2` 建立草稿。

简洁操作见 `help`、`describe v2:group.compose` 和 `api/commands.v2-experimental.schema.json`；`advanced.v1.*` 是在同一事务里保留旧原生能力的高级入口。示例中的 note-card 使用真实组局部坐标与 linked 文字定位。结构校验和本示例不等于人工视觉审阅已通过。
